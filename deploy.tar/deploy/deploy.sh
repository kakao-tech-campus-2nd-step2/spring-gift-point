#!/bin/bash

DOCKER_COMPOSE_VERSION="1.29.2"


echo "Installing Docker..."
sudo apt-get update
sudo apt install docker.io
sudo service docker start
sudo chmod 666 /var/run/docker.sock

echo "Installing Docker Compose..."
sudo curl -L "https://github.com/docker/compose/releases/download/$DOCKER_COMPOSE_VERSION/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

sudo docker-compose down

echo "Starting Docker Compose..."
sudo docker-compose up -d

echo "Deployment completed!"

